To run the java application
1. Place Driver.java FileIO.java LinkedList.java Sort.java and Node.java into the same directory
2. Place the input text files into the same directory as the java files
3. Compile the java files with "javac *.java"
4. Run the program with the command line
          java Driver x y
   Where x is the input file name with no file extension eg. input
   and y is the output file name with no file extension eg. output
