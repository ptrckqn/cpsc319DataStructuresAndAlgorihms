To run the java application
1. Place Driver.java FileIO.java Node.java and BinarySearchTree.java into the same directory
2. Place the input text files into the same directory as the java files
3. Compile the java files with "javac *.java"
4. Run the program with the command line
          java Driver x y z
   Where x is the input file name with no file extension eg. input
   y is the first output file name with no file extension eg. output1
   and z is the second output file with no file extension eg. output2

The bonus portion of the assignment was not completed.